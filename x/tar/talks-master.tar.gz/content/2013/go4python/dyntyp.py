#!/usr/bin/python

import random

name = 'pythonista'

# This code only works half of the time.
if random.random() > 0.5:
	print 'hey '+name+', you win!'
else:
	print 'sorry '+nane+', you lose'
