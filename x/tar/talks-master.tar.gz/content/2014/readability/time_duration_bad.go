// +build ignore,OMIT

package sample // OMIT

var rpcTimeoutSecs = 30 // Thirty seconds  // HL
