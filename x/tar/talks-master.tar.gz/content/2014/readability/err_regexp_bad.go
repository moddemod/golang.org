// +build ignore,OMIT

package sample // OMIT

import "regex" // OMIT

var whitespaceRegex, _ = regexp.Compile("\\s+")
