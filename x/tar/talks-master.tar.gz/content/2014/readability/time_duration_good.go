// +build ignore,OMIT

package sample // OMIT

import "time" // OMIT

var rpcTimeout = 30 * time.Second // HL
