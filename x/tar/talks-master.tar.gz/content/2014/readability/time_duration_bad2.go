// +build ignore,OMIT

package sample // OMIT

import "time" // OMIT

var rpcTimeout = time.Duration(30) * time.Second // Thirty seconds  // HL
