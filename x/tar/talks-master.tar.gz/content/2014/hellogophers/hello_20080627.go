// +build ignore,OMIT

package main

func main() {
	print "hello, world\n";
}
