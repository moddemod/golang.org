// +build ignore,OMIT

package main

import "fmt"

func main() {
	fmt.Println("Hello, Gophers (some of whom know 日本語)!")
}
