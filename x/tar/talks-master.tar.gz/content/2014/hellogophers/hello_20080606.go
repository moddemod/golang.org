// +build ignore,OMIT

package main

func main() int {
	print "hello, world\n";
	return 0;
}
