// +build ignore,OMIT

package main

import "fmt"

func main() {
	fmt.printf("hello, world\n");
}
