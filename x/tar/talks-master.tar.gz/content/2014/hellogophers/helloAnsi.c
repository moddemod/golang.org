#include <stdio.h>

main(void)
{
	printf("hello, world\n");
}
