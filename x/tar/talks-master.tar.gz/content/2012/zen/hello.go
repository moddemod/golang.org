// +build ignore,OMIT

package main

import "fmt"

func main() {
	fmt.Println("Hello, Pythonistas!")
}
