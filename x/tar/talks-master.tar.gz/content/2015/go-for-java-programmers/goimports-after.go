// +build ignore,OMIT

package main

import (
	"fmt"

	"golang.org/x/tools/present"
)

func main() {
	fmt.Println(present.Image{})
}
