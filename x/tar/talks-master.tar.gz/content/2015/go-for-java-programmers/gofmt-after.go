// +build ignore,OMIT

package main

import "fmt"

func main() {
	for i := 0; i < 3; i++ {
		fmt.Println("Hello, world")
	}
}
