// +build ignore,OMIT

package main

func main() {
	fmt.Println(present.Image{})
}
