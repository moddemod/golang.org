// +build ignore,OMIT

package main

import "fmt"

func main() {
	fmt.Printf("%T %T", 2.0, 2.0<<0)
}
