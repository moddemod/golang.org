protoc ./search-only.proto --go_out=plugins=grpc:.
